package com.urlshortener.createshorturl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateshorturlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreateshorturlApplication.class, args);
	}

}
